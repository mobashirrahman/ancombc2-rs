# Class definitions only; see DESCRIPTION.
#
# The slot names are the union of the ones phyloseq has used. The serialized
# objects in microbiome 1.24 carry `sam_data` and `phy_tree` (the older names)
# while the current package calls them `sample_data` and `tree`, so a
# definition matching only one set fails to find the other. Declaring the union
# means both serializations read, and reading a slot an object does not carry
# yields NULL -- which the caller sees rather than an error.
setClass("otu_table",
         representation(data = "ANY", taxa_are_rows = "logical"),
         prototype(data = matrix(numeric(0), 0, 0), taxa_are_rows = TRUE))
setClass("sample_data", representation(data = "ANY"))
setClass("taxonomyTable", representation(data = "ANY"))
setClass("refseq", representation(sequences = "ANY", names = "ANY"))
setClass("tree", representation(phylo = "ANY"))
setClass("physeq",
         representation(otu_table = "otu_table",
                        sample_data = "sample_data",
                        sam_data = "sample_data",
                        refseq = "refseq",
                        tree = "tree",
                        phy_tree = "tree",
                        tax_table = "taxonomyTable"))
